<?= $this->include('template/header'); ?>

<h1 class="judul">Customer Service</h1>

<div class="container" style="margin-left:165px">
  <div class="row">
    <div class="col-4">
      <div class="loket">
          Panggilan Antrian
      </div>
      <div class="box"></div>
      <div class="loket">
        LOKET 1
      </div>
    </div>
    <div class="col-6">
      <div class="loket">
          2 of 3
      </div>
      <div class="box"></div>
    </div>
</div>
<div class="row">
    <div class="col-2">
      <div class="loket">
      3 of 3
      </div>
      <div class="box_kecil"></div>
    </div>
    <div class="col-2">
    <div class="loket">
      3 of 3
      </div>
      <div class="box_kecil"></div>
    </div>
    <div class="col-2">
    <div class="loket">
      3 of 3
      </div>
      <div class="box_kecil"></div>
    </div>
    <div class="col-2">
    <div class="loket">
      3 of 3
      </div>
      <div class="box_kecil"></div>
    </div>
    <div class="col-2">
    <div class="loket">
      3 of 3
      </div>
      <div class="box_kecil"></div>
    </div>
  </div>
</div>
<?= $this->include('template/footer'); ?>