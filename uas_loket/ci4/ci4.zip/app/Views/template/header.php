<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $title; ?></title>
    <link rel="stylesheet" href="<?= base_url('/style.css');?>">
    <link rel="stylesheet" href="<?= base_url('/bootstrap.css');?>">
</head>
<body>
    <div id="container">
    <header>
        <h1>Kantor Polisi</h1>
        <h2>Cepat | Mudah | Ramah | Prosedural</h2>
        <hr>
        <h3>Jl. Raya Imam Bonjol No.17, Sukadanau, Kec. Cikarang Bar., Bekasi, Jawa Barat 17488</h3>
    </header>
    <nav style="text-align:center;padding:15px 30px;">
    Selamat Datang
    </nav>
    <section id="wrapper">
        <section id="main"> 